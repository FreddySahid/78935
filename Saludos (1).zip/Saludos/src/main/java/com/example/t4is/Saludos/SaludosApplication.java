package com.example.t4is.Saludos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludosApplication.class, args);
	}

}
