package com.example.t4is.Saludos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludosApplicationTests {

	@Test
	void contextLoads() {
	}

}
